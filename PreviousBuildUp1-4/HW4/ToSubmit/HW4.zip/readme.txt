Compilation:
  Compile with gcc ./filter.c -o filter.o
Arguments:
  If not require to compare result against an existed copy:
    ./filter <path/to/coeff.in> <path/to/data.in> <path/to/output.out>
  If compare is needed aginst an existed copy:
    ./filter <path/to/coeff.in> <path/to/data.in> <path/to/output.out> <path/to/file/to/compare>
